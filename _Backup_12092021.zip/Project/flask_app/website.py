def hello():
	return <img src="{{url_for('static', filename='01._SRC_BYTES-CLASS.jpg')}}" align="middle" />