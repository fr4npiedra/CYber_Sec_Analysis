def hello():
	return "hello"